from Model import create_model


















#---------------------------------------------
# The following method would create the model 
#---------------------------------------------
model = create_model()
